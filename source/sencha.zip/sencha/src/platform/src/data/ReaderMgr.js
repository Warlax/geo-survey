/**
 * @class Ext.data.ReaderMgr
 */
Ext.data.ReaderMgr = new Ext.AbstractManager({
    typeName: 'rtype'
});