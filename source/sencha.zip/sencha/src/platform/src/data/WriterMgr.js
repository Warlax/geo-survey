Ext.data.WriterMgr = new Ext.AbstractManager({
    
});