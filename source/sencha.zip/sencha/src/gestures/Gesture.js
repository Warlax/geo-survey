Ext.gesture.Gesture = Ext.extend(Object, {    
    listenForStart: true,
    listenForEnd: true,
    listenForMove: true,
    
    touches: 1,
    
    constructor : function(config) {
        config = config || {};
        Ext.apply(this, config);
        
        this.target = Ext.getDom(this.target);
        this.listeners = {};
        
        // <debug>
        if (!this.target) {
            throw 'Trying to bind a ' + this.type + ' event to element that does\'nt exist: ' + target;
        }
        // </debug>
        
        this.id = this.target.id + '-' + this.type;
        
        Ext.gesture.Gesture.superclass.constructor.call(this);
        Ext.gesture.Manager.register(this);
    },
    
    addListener : function(ename, listener) {
        this.listeners[ename] = this.listeners[ename] || [];
        this.listeners[ename].push(listener);
    },
    
    removeListener : function(ename, listener) {
        var listeners = this.listeners[ename];
            
        if (listeners) {
            listeners.remove(listener);
            if (listeners.length == 0) {
                delete this.listeners[ename];
            }
            for (ename in this.listeners) {
                if (this.listeners.hasOwnProperty(ename)) {
                    return;
                }
            }
            this.listeners = null;
        }
    },
    
    fire : function(type, e, args) {
        var listeners = this.listeners[type],
            ln = listeners && listeners.length,
            lock = Ext.gesture.Manager.locks[type],
            i;
        
        if (lock && lock !== this.id) {
            return false;
        }
        
        if (ln) {
            args = Ext.apply(args || {}, {
                type: type,
                gesture: this,
                target: (e.target.nodeType == 3) ? e.target.parentNode : e.target
            });
            
            for (i = 0; i < ln; i++) {
                listeners[i](e, args);
            }
        }
        
        return true;
    },
    
    stop : function() {
        Ext.gesture.Manager.stopGesture(this);
    },
    
    lock : function() {
        var args = arguments,
            ln = args.length,
            i;
            
        for (i = 0; i < ln; i++) {
            Ext.gesture.Manager.locks[args[i]] = this.id;
        }
    },
    
    unlock : function() {
        var args = arguments,
            ln = args.length,
            i;
            
        for (i = 0; i < ln; i++) {
            if (Ext.gesture.Manager.locks[args[i]] == this.id) {
                delete Ext.gesture.Manager.locks[args[i]]; 
            }
        }        
    },
    
    onTouchStart : Ext.emptyFn,
    onTouchMove : Ext.emptyFn,
    onTouchEnd : Ext.emptyFn,
    
    destroy : function() {
        this.stop();
        this.listeners = null;
        Ext.gesture.Manager.unregister(this);
    }
});